/**
 * 
 */
/**
 * 
 */
module crudminiproject {
	requires java.sql;
}