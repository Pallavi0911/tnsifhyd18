package oop3polymorphism;

public class PolymorphismMOverloadMain {
	
	public static void main(String[] args) {
		PolymorphismMOverload m1 = new PolymorphismMOverload();
		m1.display();
		
		System.out.println("\n");
		
		m1.display('#');
	}

}
