package staticinstance;

public class typeconversion {
	public static void main(String[] args) {
		byte x=10;
		int y=x;
		System.out.println(y);
		typeconversion t1=new typeconversion();
		System.out.println(t1);
		
	}
	


}
