package core.superr;

public class Animal1SuperParentVariable {
	
	String color="white";

}
