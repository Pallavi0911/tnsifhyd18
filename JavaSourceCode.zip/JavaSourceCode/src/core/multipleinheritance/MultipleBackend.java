package core.multipleinheritance;

public interface MultipleBackend {
	
	//abstract method
	public void connectServer() ;

}
