package core.accessmodifiers;

public class PrivateA {
	
	void display()
	{
	System.out.println("TNS Sessions");
	}
}
