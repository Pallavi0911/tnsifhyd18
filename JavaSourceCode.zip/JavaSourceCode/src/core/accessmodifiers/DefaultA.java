package core.accessmodifiers;

public class DefaultA {
	
	public void display() {
		System.out.println("TNS sessions");
	}

}
