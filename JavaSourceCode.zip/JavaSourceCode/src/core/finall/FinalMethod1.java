package core.finall;

public class FinalMethod1 {
	
	void run() {
		System.out.println("Running");
	}

}
