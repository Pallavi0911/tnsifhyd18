package core.accessmodifiers1;

import core.accessmodifiers.DefaultA;

public class Default2Main {
	
	public static void main(String[] args) {
		DefaultA a2 = new DefaultA();
		a2.display();
	}

}
