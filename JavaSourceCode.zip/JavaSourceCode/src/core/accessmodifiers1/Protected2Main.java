package core.accessmodifiers1;

import core.accessmodifiers.*;

public class Protected2Main extends ProtectedA {
	
	public static void main(String[] args) {
		
		Protected2Main p3 = new Protected2Main();
		p3.display();
		
	}

}
