package core.interfacee;

public interface Phone {
	
	String processor(); //abstract method 
	String OS(); // abstract method
	int spaceInGB(); //abstract method

}
