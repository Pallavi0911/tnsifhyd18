package opp4inheritance;

public class HierarchialInheritenceA {
	
	public void display() {
		System.out.println("I am method from class A");
	}

}
