package opp4inheritance;

public class Dog extends Animal{
	
	public void display() {
		System.out.println("My name is " + name);
	}

}
