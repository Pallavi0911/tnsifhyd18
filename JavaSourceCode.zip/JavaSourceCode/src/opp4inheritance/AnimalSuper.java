package opp4inheritance;

public class AnimalSuper {
	
	
	public void eat() {
		System.out.println("I can eat");
	}

}
