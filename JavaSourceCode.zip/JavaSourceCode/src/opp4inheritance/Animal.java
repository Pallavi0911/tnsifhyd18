package opp4inheritance;

public class Animal {
	
	String name;
	public void eat() {
		System.out.println("I can eat");
	}

}
