package iplpackage.miniproject1;

public class Srh {
	public void batsman() {
		System.out.println("Travis Head");
		System.out.println("Abhishek Sharma");
	}
	public void bowlers() {
		System.out.println("Deepak Chahar");
		System.out.println("Abdul Samad");

	}
}