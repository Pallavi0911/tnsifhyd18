package iplpackage.miniproject1;
public class mainclass {
public static void main(String[] args) {
	Rcb r1=new Rcb() ;{
	
		r1.batsman();
		r1.bowlers();
	
	}
	Csk c1=new Csk();{
		c1.batsman();
		c1.bowlers();
	}
	Srh s1=new Srh();{
		s1.batsman();
		s1.bowlers();
	}
}

}