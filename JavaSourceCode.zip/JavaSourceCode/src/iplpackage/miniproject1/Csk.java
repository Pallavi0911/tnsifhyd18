package iplpackage.miniproject1;

public class Csk {
	public void batsman() {
		System.out.println("M.S Dhoni");
		System.out.println("Virat Kohil");
	}
	public void bowlers() {
		System.out.println("Deepak Chahar");
		System.out.println("Matheesha Pathurana");
		
	}


}
