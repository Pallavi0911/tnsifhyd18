package iplpackage.miniproject1;

public class Rcb {
	public void batsman() {
		System.out.println("Virat Kohil");
		System.out.println("Maxwell");
	}
	public void bowlers() {
		System.out.println("Harshal Patel");
		System.out.println("MD. Siraj");
	}

}
